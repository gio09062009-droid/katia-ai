
23/storage/emulated/0/CodeOnTheGoProjects/KatiaSystem1795365981076"�
app/build.gradle.ktsH/storage/emulated/0/CodeOnTheGoProjects/KatiaSystem/app/build.gradle.kts�) 後��4*@b95ef0e9fe361d0d1bdf19eab3caa80c881495e1ef57a2c7db1e9ca2b001c147"�
build.gradle.ktsD/storage/emulated/0/CodeOnTheGoProjects/KatiaSystem/build.gradle.kts� �����4*@894c92aa66d7ae56d21573617b028f15675252935e41e9fd8165c4b41cec3d37"�
gradle.propertiesE/storage/emulated/0/CodeOnTheGoProjects/KatiaSystem/gradle.properties�
 񿌡�4*@194f9064020d41d27decd9e74375ff1459b75854f0d68f38e0375ca3b4f031b4"�
(gradle/wrapper/gradle-wrapper.properties\/storage/emulated/0/CodeOnTheGoProjects/KatiaSystem/gradle/wrapper/gradle-wrapper.properties� �����4*@80dbd23007872ba453e1dcc698121d3c18d71e937a413f7543761a6d4ce93e40"�
settings.gradle.ktsG/storage/emulated/0/CodeOnTheGoProjects/KatiaSystem/settings.gradle.kts� �����4*@359a0155431ff01aa35046d61df9f79d186ec85febf363a1bfe9f63441a39c38*�
N/storage/emulated/0/CodeOnTheGoProjects/KatiaSystem/.cg/gradle-sync/project.pb@4c4e4f98f994a01a1ffd51ccf727f53894b651d7c5a9b8ed8567ff9296409c00